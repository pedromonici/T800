#include "packet_queue.h"
#include <string.h>

void pq_insert(PacketQueue *pq, Conn_id_t *id){
	pq->flows[pq->pos++] = *id;
	pq->pos %= TAM;
    pq->is_initialized = true;
}

void pq_erase(PacketQueue *pq){
	memset(&pq->flows, 0, TAM * sizeof(Conn_id_t));
	pq->pos = 0;
}
