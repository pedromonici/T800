#ifndef _PACKET_QUEUE_H_
#define _PACKET_QUEUE_H_

#include "lwip/pbuf.h"
#include "lwip/connection_id.h"

#define TAM 4

typedef struct _packet_queue{
	Conn_id_t flows[TAM];
	u8_t pos;
    bool is_initialized;
} PacketQueue;

void pq_insert(PacketQueue *, Conn_id_t *id);
void pq_erase(PacketQueue *pq);

#endif
