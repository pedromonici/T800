#pragma once
#define _ESP_NETIF_SUPPRESS_LEGACY_WARNING_
#define __ARCH_CC_H__
#define __XTENSA_API_H__
#define IRAM_ATTR
#define FLAG_ATTR(TYPE)
#define SSIZE_MAX INT_MAX
#undef assert
#define assert(x)
