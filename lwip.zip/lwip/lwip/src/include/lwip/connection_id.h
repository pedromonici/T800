#ifndef _CONN_ID_H_
#define _CONN_ID_H_

#include "lwip/opt.h"

#include "lwip/def.h"
#include "lwip/pbuf.h"
#include "lwip/ip4_addr.h"
#include "lwip/err.h"
#include "lwip/netif.h"
#include "lwip/prot/ip4.h"
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _conn_id_t {
  ip4_addr_p_t ip_src;
  ip4_addr_p_t ip_dst;
  u16_t port_src;
  u16_t port_dst;
} Conn_id_t;

void firewall_get_key_from_id(Conn_id_t id, u8_t *key);

#ifdef __cplusplus
}
#endif

#endif
