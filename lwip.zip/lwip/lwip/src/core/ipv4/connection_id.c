#include "lwip/connection_id.h"

void firewall_get_key_from_id(Conn_id_t id, u8_t *key) {
    size_t offset = 0;
    memcpy(key+offset,    &id.ip_src,   sizeof(ip4_addr_p_t));
    offset += sizeof(ip4_addr_p_t);
    memcpy(key+offset,    &id.ip_dst,   sizeof(ip4_addr_p_t));
    offset += sizeof(ip4_addr_p_t);
    memcpy(key+offset,    &id.port_src, sizeof(u16_t));
    offset += sizeof(u16_t);
    memcpy(key+offset,    &id.port_dst, sizeof(u16_t));
}

