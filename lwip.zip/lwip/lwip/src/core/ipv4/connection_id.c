#include "lwip/connection_id.h"

void firewall_get_key_from_id(Conn_id_t id, u8_t *key) {
    size_t offset = 0;
    memcpy(key+offset,    &id.ip_src,   sizeof(ip4_addr_p_t));
    offset += sizeof(ip4_addr_p_t);
    memcpy(key+offset,    &id.ip_dst,   sizeof(ip4_addr_p_t));
    offset += sizeof(ip4_addr_p_t);
    memcpy(key+offset,    &id.port_src, sizeof(u16_t));
    offset += sizeof(u16_t);
    memcpy(key+offset,    &id.port_dst, sizeof(u16_t));
}

bool firewall_id_cmp(Conn_signature_t* id1, Conn_signature_t* id2) {
    return  id1.ip_src == id2.ip_src &&
            id1.ip_dst == id2.ip_dst &&
            id1.port_src == id2.port_src &&
            id1.port_dst == id2.port_dst
}

bool firewall_signature_cmp(Conn_signature_t* sig1, Conn_signature_t* sig2) {
    bool iph_checksum_equals = IPH_CHKSUM(sig1->iphdr) == IPH_CHKSUM(sig2->iphdr);
    if (!iph_checksum_equals) return false;

    return sig1->tcphdr.chksum == sig2->tcphdr.chksum;
}