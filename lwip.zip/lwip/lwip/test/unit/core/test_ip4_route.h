#ifndef LWIP_HDR_TEST_IP4ROUTE_H
#define LWIP_HDR_TEST_IP4ROUTE_H

#include "../lwip_check.h"

Suite *ip4route_suite(void);

#endif
